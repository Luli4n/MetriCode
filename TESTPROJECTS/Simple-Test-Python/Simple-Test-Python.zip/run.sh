#!/bin/bash
echo "Uruchamiam benchmark projektu w Pythonie"
python3 script.py